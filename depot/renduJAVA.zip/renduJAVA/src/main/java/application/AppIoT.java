package application;

import application.control.AppMainFrame;;

public class AppIoT {

    /**
     * Lancement de la fenêtre principale.
     */

    public static void main(String[] args) {
        System.out.println("Lancement de l'app");
        AppMainFrame.runApp();
    }

}
