Pour lancer le JAR : 

- Veuillez vous déplacer vers le dossier intitulé : "lancement_Jar" puis dans le dossier "JAR"
- double cliquer sur "demo-1.0-SNAPSHOT.jar". 


Pour visualiser la JavaDOC : celle-ci se trouve dans le dossier intitulé : "documentationJavaDoc". 


Pour récupérer le code source de l'application Java : celui-ci se trouver dans le dossier intitulé "src".